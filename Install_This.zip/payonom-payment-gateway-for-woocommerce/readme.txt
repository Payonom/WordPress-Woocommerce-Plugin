=== Plugin Name ===
Contributors: Payonom.con
Tags: WooCommerce, Payment Gateway, Payonom
Tested up to: 5.9.1
Stable tag: 1.0.0
License: GPLv2 or later
Payonom Payment Gateway for WooCommerce

![Plugin Logo](assets/img/logo.png)


== Description ==
Integrate Payonom payment gateway with the WooCommerce plugin. Payonom is a Bangladeshi Payment Gateway that allows you to accept online payments securely and easily.

== Installation ==

Install and activate the WooCommerce plugin.
Upload and activate the Payonom Payment Gateway plugin.
Configure the Payonom settings in the WooCommerce payment gateway options.
== Changelog ==
= 1.0 =

Initial release.